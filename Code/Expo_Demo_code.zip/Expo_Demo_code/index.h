#ifndef INDEX_H
#define INDEX_H
 
const char index_html[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initialscale=1,maximum-scale=1">
  <title>SproutBot Dashboard</title>
    <link rel = "stylesheet" href="https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css">
<style>
 
  :root {
      /*--main-color: hsl(150, 72%, 53%);*/ /*Old Website Color*/
        --main-color: rgba(53, 136, 86);
        --color-dark: #1D2231;
        --text-grey: #8390A2;
    }
   
    * {
      padding: 0;
        margin: 0;
        box-sizing: border-box;
        list-style-type: none;
        text-decoration: none;
        font-family: 'Poppins' , sans-serif;
    }
   
    .sidebar {
        width: 345px;
        position: fixed;
        left: 0;
        top: 0;
        height: 100%;
        background: var(--main-color);
        z-index: 100;
        transition: width 300ms;
    }
 
    .sidebar-brand {
        height: 90px;
        padding: 1rem 0rem 1rem 2rem;
        color: #fff;
    }
 
    .sidebar-brand span {
        display: inline-block;
        padding-right: 1rem;
    }
 
    .sidebar-menu {
        margin-top: 1rem;
    }
 
    .sidebar-menu li {
        width: 100%;
        margin-bottom: 1.7rem;
        padding-left: 2rem;
    }
 
    .sidebar-menu a {
        padding-left: 1rem;
        display: block;
        color: #fff;
        font-size: 1.1rem;
    }
 
    .sidebar-menu a.active {
        background: #fff;
        padding-top: 1rem;
        padding-bottom: 1rem;
        color: var(--main-color);
        border-radius: 30px 0px 0px 30px;
    }
 
    .sidebar-menu  a span:first-child {
        font-size: 1.5rem;
        padding-right: 1rem;
    }
 
    #nav-toggle:checked + .sidebar {
        width: 70px;
    }
 
    #nav-toggle:checked + .sidebar .sidebar-brand,
    #nav-toggle:checked + .sidebar li {
        padding-left: 1rem;
        text-align: center;
    }
 
    #nav-toggle:checked + .sidebar li a {
        padding-left: 0rem;
    }
 
    #nav-toggle:checked + .sidebar .sidebar-brand h2 span:last-child,
    #nav-toggle:checked + .sidebar li a span:last-child {
        display: none;
    }
 
    #nav-toggle:checked ~ .main-content {
        margin-left: 70px;
    }
 
    #nav-toggle:checked ~ .main-content header {
        width: calc(100% - 70px);
        left: 70px;
    }
 
    .main-content {
        transition: margin-left 300ms;
        margin-left: 345px;
    }
 
    header {
        background: #fff;
        display: flex;
        justify-content: space-between;
        padding: 1rem 1.5rem;
        box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.2);
        position: fixed;
        left: 345px;
        width: calc(100% - 345px);
        top: 0;
        z-index: 100;
        transition: left 300ms;
    }
 
    #nav-toggle {
        display: none;
    }
 
    header h2 {
        color: #222;
    }
 
    header label span {
        font-size: 1.7rem;
        padding-right: 1rem;
    }
 
    .user-wrapper {
        display: flex;
        align-items: center;
    }
 
    .user-wrapper small {
        display: inline-block;
        color: var(--text-grey);
    }
 
    main {
        margin-top: 85px;
        padding: 2rem 1.5rem;
        background: #f1f5f9;
        min-height: calc(100vh - 90px);
    }
 
    .cards {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        grid-gap: 2rem;
        margin-top: 1rem;
    }
 
    .card-single {
        display: flex;
        justify-content: space-between;
        background: #fff;
        padding: 2rem;
        border-radius: 2px;
    }
 
    .card-single div:last-child span {
        font-size: 3rem;
        color: var(--main-color);
    }
 
    .card-single div:first-child span{
        color: var(--text-grey);
    }
 
    .card-single:last-child {
        background: var(--main-color);
    }
 
    .card-single:last-child h1,
    .card-single:last-child div:first-child span,
    .card-single:last-child div:last-child span {
        color: #fff;
    }
 
    .recent-grid {
        margin-top: 3.5rem;
        display: grid;
        grid-gap: 2rem;
        grid-template-columns: 65% auto;
    }
 
    .card {
        background: #fff;
        border-radius: 5px;
    }
 
    .card-header,
    .cardbody {
        padding: 1rem;
    }
 
    .card-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        border-bottom: 1px solid #f0f0f0
    }
 
    .card-header button {
        background: var(--main-color);
        border-radius: 10px;
        color: #fff;
        font-size: .8rem;
        padding: .5rem 1rem;
        border: 1px solid var(--main-color);
 
    }
 
    table {
        border-collapse: collapse;
 
    }
 
    thead tr {
        border-top: 1px solid #f0f0f0;
        border-bottom: 1px solid #f0f0f0;
    }
 
    thead td {
        font-weight: 700;
    }
   
    td {
        padding: .5rem 1rem;
        font-size: .9rem;
        color: #222;
    }
 
    td .status {
        display: inline-block;
        height: 20px;
        width: 20px;
        border-radius: 50%;
        margin-right: 1rem;
    }
 
    tr td:last-child {
        display: flex;
        align-items: center;
    }
 
    .status.green {
        background: green;
    }
 
    .status.orange {
        background: orange;
    }
 
    .status.red {
        background: red;
    }
 
    .status.blue {
        background: blue;
    }
 
    .table-responsive {
        width: 100%;
        overflow-x: auto;
    }
 
    .plant {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: .5rem 0.7rem;
    }
 
    .info {
        display: flex;
        align-items: center;
    }
 
    .info img {
        border-radius: 50%;
        margin-right: 1rem;
    }
 
    .info h4 {
        font-size: .8rem;
        font-weight: 700;
        color: #222;
    }
 
    .info small {
        margin-left: 1rem;
        font-weight: 600;
        color: var(--text-grey);
    }
 
    .progress-bar {
        height: 10px;
        background-color: #f0f0f0;
        border-radius: 5px;
        margin-top: 5px;
    }
 
    .water-level {
        height: 100%;
        background-color: var(--main-color); /* Change color as needed */
        border-radius: 5px;
        transition: width 0.5s ease-in-out;
    }
 
    @media only screen and (max-width: 1200px){
        .sidebar {
            width: 70px;
        }
 
        .sidebar .sidebar-brand,
        .sidebar li {
            padding-left: 1rem;
            text-align: center;
        }
 
        .sidebar li a {
            padding-left: 0rem;
        }
 
        .sidebar .sidebar-brand h2 span:last-child,
        .sidebar li a span:last-child {
            display: none;
        }
 
        .main-content {
            margin-left: 70px;
        }
 
        .main-content header {
            width: calc(100% - 70px);
            left: 70px;
        }
    }
 
    @media only screen and (max-width: 960px) {
        .cards {
            grid-template-columns: repeat(3, 1fr);
        }
 
        .recent-grid {
            grid-template-columns: 60% 40%;
        }
    }
 
    @media only screen and (max-width: 768px) {
        .cards {
            grid-template-columns: repeat(2, 1fr);
        }
 
        .recent-grid {
            grid-template-columns: 100%;
        }
 
        .sidebar {
            left: -100% !important;
        }
 
        header h2 {
            display: flex;
            align-items: center;
        }
 
        header h2 label {
            display: inline-block;
            background: var(--main-color);
            padding-right: 0rem;
            margin-right: 1rem;
            height: 40px;
            width: 40px;
            border-radius: 50%;
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center !important;
        }
 
        header h2 span {
            text-align: center;
            padding-right: 0rem;
        }
 
        header h2 {
            font-size: 1.1rem;
        }
 
        .main-content {
            width: 100%;
            margin-left: 0rem;
        }
 
        header {
            width: 100% !important;
            left: 0 !important;
        }
 
        #nav-toggle:checked + .sidebar {
            left: 0 !important;
            z-index: 100;
            width: 345px;
        }
 
        #nav-toggle:checked + .sidebar .sidebar-brand,
        #nav-toggle:checked + .sidebar li {
            padding-left: 2rem;
            text-align: left;
        }
 
        #nav-toggle:checked + .sidebar li a {
            padding-left: 1rem;
        }
 
        #nav-toggle:checked + .sidebar .sidebar-brand h2 span:last-child,
        #nav-toggle:checked + .sidebar li a span:last-child {
            display: inline;
        }
 
        #nav-toggle:checked ~ .main-content{
            margin-left: 0rem !important;
        }
    }
 
    @media only screen and (max-width: 560px) {
        .cards {
            grid-template-columns: 100%;
        }
    }
 
    .arm-button {
        position: absolute;
        top: 90px; /* Adjust as needed to place it below the header */
        right: 25px; /* Adjust as needed to position it on the right */
        background-color: var(--main-color);
        color: #fff;
        border: none;
        border-radius: 5px;
        padding: 10px 20px;
        font-size: 1rem;
        cursor: pointer;
        transition: background-color 0.3s;
    }
 
    .arm-button:hover {
        background-color: rgba(53, 136, 86, 0.8); /* Adjust as needed */
    }
 
    .icon-big {
        font-size: 2.5rem; /* Adjust the size as needed */
        margin-right: 20px; /* Adjust the margin as needed */
    }
 
</style>
</head>
<body>
 
    <input type="checkbox" id="nav-toggle">
  <div class="sidebar">
      <div class="sidebar-brand">
          <h2><span class="las la-seedling"></span> <span>SproutBot</span>
            </h2>
            </div>
           
            <div class="sidebar-menu">
              <ul>
                  <li>
                      <a href="" class="active"><span class="las la-home"></span>
                        <span>Dashboard</span></a>
                    </li>
                    <li>
                      <a href=""><span class="las la-leaf"></span>
                        <span>My Plants</span></a>
                    </li>
                    <li>
                      <a href=""><span class="las la-laptop-code"></span>
                        <span>My Robot</span></a>
                    </li>
                    <li>
                      <a href=""><span class="las la-trophy"></span>
                        <span>About</span></a>
                    </li>
               </ul>
           </div>
       </div>
                   
 
    <div class="main-content">
        <header>
          <h2>
              <label for="nav-toggle">
                  <span class="las la-bars"></span>
                </label>
               
                Dashboard
            </h2>
           
            <div class="user-wrapper">
              <div>
                  <h4>Mina Demian</h4>
                    <small>Admin</small>
       
        </header>
       
        <button id="armButton" class="arm-button" onclick="triggerArmFunction()">Test Arm</button>
       
        <main>
       
          <div class="cards">
              <div class="card-single">
                  <div>
                      <h1 id="totalPlants">--</h1>
                        <span>Plants</span>
                    </div>
                    <div>
                      <span class="las la-leaf"></span>
                    </div>
                </div>
 
                <div class="card-single">
                  <div>
                      <h1 id="successfulTrips">--</h1>
                        <span>Successful Trips Today</span>
                    </div>
                    <div>
                      <span class="las la-calendar-check"></span>
                    </div>
                </div>
 
                <div class="card-single">
                  <div>
                      <h1 id="totalTrips">--</h1>
                        <span>Trips Today</span>
                    </div>
                    <div>
                      <span class="las la-map"></span>
                    </div>
                </div>
               
                <div class="card-single">
                  <div>
                      <h1 id="waterUsed">--</h1>
                        <span>Water Used Today</span>
                    </div>
                    <div>
                      <span class="las la-tint"></span>
                    </div>
                </div>
            </div>
 
            <div class="recent-grid">
                <div class="projects">
                    <div class="card">
                        <div class="card-header">
                            <h2>Water Runs</h2>
 
                            <button>See all <span class="las la-arrow-right">
                            </span></button>
                        </div>
 
                        <div class="card-body">
                            <div class="table-responsive">
                                <table width="100%">
                                    <thead>
                                        <tr>
                                            <td>Time</td>
                                            <td>Plant</td>
                                            <td>Status</td>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <!--
                                        <tr>
                                            <td>7:00 pm</td>
                                            <td>Plant 1</td>
                                            <td>
                                                <span class="status blue"></span>
                                                Waiting
                                            </td>
                                        </tr>
                                        -->
                                        <tr>
                                            <td>9:48 am</td>
                                            <td>Plant 3</td>
                                            <td>
                                                <span class="status green"></span>
                                                Successful
                                            </td>
                                        </tr>
   
                                        <tr>
                                            <td>9:33 am</td>
                                            <td>Plant 2</td>
                                            <td>
                                                <span class="status red"></span>
                                                Failed
                                            </td>
                                        </tr>
   
                                        <tr>
                                            <td>8:07 am</td>
                                            <td>Plant 1</td>
                                            <td>
                                                <span class="status green"></span>
                                                Successful
                                            </td>
                                        </tr>
   
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
 
                <div class="Plants">
                    <div class="card">
                        <div class="card-header">
                            <h2>Water Levels</h2>
                            <button>See all <span class="las la-arrow-right">
                            </span></button>
                        </div>
 
                        <div class="card-body">
                            <div class="Plant">
                                <div class="info">
                                    <span class="icon-big lab la-canadian-maple-leaf"></span>
                                    <h4>Plant 1</h4>
                                    <small id="plant1WaterLevel">%d%% </small>
                                </div>
                                <div class="progress-bar">
                                    <div id="plant1WaterLevelBar" class="water-level" style="width: %d%%;"></div>
                                </div>
                            </div>
                   
                            <div class="Plant">
                                <div class="info">
                                    <span class="icon-big la la-pagelines"></span>
                                    <h4>Plant 2</h4>
                                    <small id="plant2WaterLevel">%d%% </small>
                                </div>
                                <div class="progress-bar">
                                    <div id="plant2WaterLevelBar" class="water-level" style="width: %d%%;"></div>
                                </div>
                            </div>
                   
                            <div class="Plant">
                                <div class="info">
                                    <span class="icon-big las la-spa"></span>
                                    <h4>Plant 3</h4>
                                    <small id="plant3WaterLevel">%d%% </small>
                                </div>
                                <div class="progress-bar">
                                    <div id="plant3WaterLevelBar" class="water-level" style="width: %d%%;"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
 
         </main>
    </div>
 
  <script>
 
  // Counter variable to keep track of button clicks
  //let armButtonClicks = 0;
 
  function triggerArmFunction() {
      // Increment the counter
      //armButtonClicks++;
 
      // Update the counter inside the button
      //document.getElementById('armCounter').innerText = armButtonClicks;
 
      // Send GET request to the arm_function endpoint with value=1
      fetch('/arm_function?value=1')
      .then(response => {
        if (response.ok) {
          console.log('Arm function triggered successfully');
        } else {
          console.error('Failed to trigger arm function');
          }
      })
      .catch(error => {
        console.error('Error triggering arm function:', error);
      });
    }
 
  // Function to fetch water level data from server
  function fetchWaterLevels() {
    fetch('/get_water_levels')
    .then(response => response.json())
    .then(data => {
        document.getElementById('plant1WaterLevel').innerText = data.plant1WaterLevel + '%';
        document.getElementById('plant1WaterLevelBar').style.width = data.plant1WaterLevel + '%';
 
        document.getElementById('plant2WaterLevel').innerText = data.plant2WaterLevel + '%';
        document.getElementById('plant2WaterLevelBar').style.width = data.plant2WaterLevel + '%';
 
        document.getElementById('plant3WaterLevel').innerText = data.plant3WaterLevel + '%';
        document.getElementById('plant3WaterLevelBar').style.width = data.plant3WaterLevel + '%';
 
        document.getElementById('totalPlants').innerText = data.totalPlants;
        document.getElementById('successfulTrips').innerText = data.successfulTrips;
        document.getElementById('totalTrips').innerText = data.totalTrips;
        document.getElementById('waterUsed').innerText = data.waterUsed + ' mL';
 
    });
}
 
      // Function to handle reload event and refresh the page
      function handleReload(event) {
        if (event.data === 'reload') {
          window.location.reload();
        }
      }
 
      // Event listener for reload event
      const events = new EventSource('/events');
      events.addEventListener('reload', fetchWaterLevels); //use handleReload instead of fetchWaterLevels if you want to refresh whole webpage
 
      // Fetch water levels when the page loads
      fetchWaterLevels();
 
      // Refresh water levels every minute
      setInterval(fetchWaterLevels, 60000);
 
      // Fetch water levels when the Whole Webpage loads if we use the Full Webpage Refresh
      //window.onload = fetchWaterLevels;
    </script>
</body>
</html>
)rawliteral";
 
#endif // INDEX_H