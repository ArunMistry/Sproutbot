#ifndef PLANT_DATA_H
#define PLANT_DATA_H

extern int plant1WaterLevel;
extern int plant2WaterLevel;
extern int plant3WaterLevel;

extern int totalPlants;
extern int successfulTrips;
extern int totalTrips;
extern float waterUsed;

#endif // PLANT_DATA_H
