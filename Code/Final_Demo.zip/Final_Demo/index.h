#ifndef INDEX_H
#define INDEX_H

const char index_html[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initialscale=1,maximum-scale=1">
	<title>SproutBot Dashboard</title>
    <link rel = "stylesheet" href="https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
<style>

	:root {
    	/*--main-color: hsl(150, 72%, 53%);*/ /*Old Website Color*/
        --main-color: rgba(53, 136, 86);
        --color-dark: #1D2231;
        --text-grey: #8390A2;
    }
    
    * {
    	padding: 0;
        margin: 0;
        box-sizing: border-box;
        list-style-type: none;
        text-decoration: none;
        font-family: 'Poppins' , sans-serif;
    }
    
    .sidebar {
        width: 345px;
        position: fixed;
        left: 0;
        top: 0;
        height: 100%;
        background: var(--main-color);
        z-index: 100;
        transition: width 300ms;
    }

    .sidebar-brand {
        height: 90px;
        padding: 1rem 0rem 1rem 2rem;
        color: #fff;
    }

    .sidebar-brand span {
        display: inline-block;
        padding-right: 1rem;
    }

    .sidebar-menu {
        margin-top: 1rem;
    }

    .sidebar-menu li {
        width: 100%;
        margin-bottom: 1.7rem;
        padding-left: 2rem;
    }

    .sidebar-menu a {
        padding-left: 1rem;
        display: block;
        color: #fff;
        font-size: 1.1rem;
    }

    .sidebar-menu a.active {
        background: #fff;
        padding-top: 1rem;
        padding-bottom: 1rem;
        color: var(--main-color);
        border-radius: 30px 0px 0px 30px;
    }

    .sidebar-menu  a span:first-child {
        font-size: 1.5rem;
        padding-right: 1rem;
    }

    #nav-toggle:checked + .sidebar {
        width: 70px;
    }

    #nav-toggle:checked + .sidebar .sidebar-brand,
    #nav-toggle:checked + .sidebar li {
        padding-left: 1rem;
        text-align: center;
    }

    #nav-toggle:checked + .sidebar li a {
        padding-left: 0rem;
    }

    #nav-toggle:checked + .sidebar .sidebar-brand h2 span:last-child,
    #nav-toggle:checked + .sidebar li a span:last-child {
        display: none;
    }

    #nav-toggle:checked ~ .main-content {
        margin-left: 70px;
    }

    #nav-toggle:checked ~ .main-content header {
        width: calc(100% - 70px);
        left: 70px;
    }

    .main-content {
        transition: margin-left 300ms;
        margin-left: 345px;
    }

    header {
        background: #fff;
        display: flex;
        justify-content: space-between;
        padding: 1rem 1.5rem;
        box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.2);
        position: fixed;
        left: 345px;
        width: calc(100% - 345px);
        top: 0;
        z-index: 100;
        transition: left 300ms;
    }

    #nav-toggle {
        display: none;
    }

    header h2 {
        color: #222;
    }

    header label span {
        font-size: 1.7rem;
        padding-right: 1rem;
    }

    .user-wrapper {
        display: flex;
        align-items: center;
    }

    .user-wrapper small {
        display: inline-block;
        color: var(--text-grey);
    }

    main {
        margin-top: 85px;
        padding: 2rem 1.5rem;
        background: #f1f5f9;
        min-height: calc(100vh - 90px);
    }

    .cards {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        grid-gap: 2rem;
        margin-top: 1rem;
    }

    .card-single {
        display: flex;
        justify-content: space-between;
        background: #fff;
        padding: 2rem;
        border-radius: 2px;
    }

    .card-single div:last-child span {
        font-size: 3rem;
        color: var(--main-color);
    }
  
    .card-single div:first-child span{
        color: var(--text-grey);
    }

    .card-single:last-child {
        background: var(--main-color);
    }

    .card-single:last-child h1,
    .card-single:last-child div:first-child span,
    .card-single:last-child div:last-child span {
        color: #fff;
    }

    .recent-grid {
        margin-top: 1.5rem;
        display: grid;
        grid-gap: 2rem;
        grid-template-columns: 65% auto;
    }

    .card {
        background: #fff;
        border-radius: 5px;
    }

    .card-header,
    .cardbody {
        padding: 1rem;
    }

    .card-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        border-bottom: 1px solid #f0f0f0
    }

    .card-header button {
        background: var(--main-color);
        border-radius: 10px;
        color: #fff;
        font-size: .8rem;
        padding: .5rem 1rem;
        border: 1px solid var(--main-color);

    }

    table {
        border-collapse: collapse;

    }

    thead tr {
        border-top: 1px solid #f0f0f0;
        border-bottom: 1px solid #f0f0f0;
    }

    thead td {
        font-weight: 700;
    }
    
    td {
        padding: .5rem 1rem;
        font-size: .9rem;
        color: #222;
    }

    td .status {
        display: inline-block;
        height: 20px;
        width: 20px;
        border-radius: 50%;
        margin-right: 1rem;
    }

    tr td:last-child {
        display: flex;
        align-items: center;
    }

    .status.green {
        background: green;
    }

    .status.orange {
        background: orange;
    }

    .status.red {
        background: red;
    }

    .status.blue {
        background: blue;
    }

    .table-responsive {
        width: 100%;
        overflow-x: auto;
    }

    .plant {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: .5rem 0.7rem;
    }

    .info {
        display: flex;
        align-items: center;
    }

    .info img {
        border-radius: 50%;
        margin-right: 1rem;
    }

    .info h4 {
        font-size: .8rem;
        font-weight: 700;
        color: #222;
    }

    .info small {
        margin-left: 1rem;
        font-weight: 600;
        color: var(--text-grey);
    }

    .progress-bar {
        height: 10px;
        background-color: #f0f0f0;
        border-radius: 5px;
        margin-top: 5px;
    }

    .water-level {
        height: 100%;
        background-color: var(--main-color); /* Change color as needed */
        border-radius: 5px;
        transition: width 0.5s ease-in-out;
    }

    @media only screen and (max-width: 1200px){
        .sidebar {
            width: 70px;
        }

        .sidebar .sidebar-brand,
        .sidebar li {
            padding-left: 1rem;
            text-align: center;
        }

        .sidebar li a {
            padding-left: 0rem;
        }

        .sidebar .sidebar-brand h2 span:last-child,
        .sidebar li a span:last-child {
            display: none;
        }

        .main-content {
            margin-left: 70px;
        }

        .main-content header {
            width: calc(100% - 70px);
            left: 70px;
        }
    }

    @media only screen and (max-width: 960px) {
        .cards {
            grid-template-columns: repeat(3, 1fr);
        }

        .recent-grid {
            grid-template-columns: 60% 40%;
        }
    }

    @media only screen and (max-width: 768px) {
        .cards {
            grid-template-columns: repeat(2, 1fr);
        }

        .recent-grid {
            grid-template-columns: 100%;
        }

        .sidebar {
            left: -100% !important;
        }

        header h2 {
            display: flex;
            align-items: center;
        }

        header h2 label {
            display: inline-block;
            background: var(--main-color);
            padding-right: 0rem;
            margin-right: 1rem;
            height: 40px;
            width: 40px;
            border-radius: 50%;
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center !important;
        }

        header h2 span {
            text-align: center;
            padding-right: 0rem;
        }

        header h2 {
            font-size: 1.1rem;
        }

        .main-content {
            width: 100%;
            margin-left: 0rem;
        }

        header {
            width: 100% !important;
            left: 0 !important;
        }

        #nav-toggle:checked + .sidebar {
            left: 0 !important;
            z-index: 100;
            width: 345px;
        }

        #nav-toggle:checked + .sidebar .sidebar-brand,
        #nav-toggle:checked + .sidebar li {
            padding-left: 2rem;
            text-align: left;
        }

        #nav-toggle:checked + .sidebar li a {
            padding-left: 1rem;
        }

        #nav-toggle:checked + .sidebar .sidebar-brand h2 span:last-child,
        #nav-toggle:checked + .sidebar li a span:last-child {
            display: inline;
        }

        #nav-toggle:checked ~ .main-content{
            margin-left: 0rem !important;
        }
    }

    @media only screen and (max-width: 560px) {
        .cards {
            grid-template-columns: 100%;
        }
    }

    .arm-button {
        position: absolute;
        top: 90px; /* Adjust as needed to place it below the header */
        right: 25px; /* Adjust as needed to position it on the right */
        background-color: var(--main-color);
        color: #fff;
        border: none;
        border-radius: 5px;
        padding: 10px 20px;
        font-size: 1rem;
        cursor: pointer;
        transition: background-color 0.3s;
    }

    .arm-button:hover {
        background-color: rgba(53, 136, 86, 0.8); /* Adjust as needed */
    }

    .icon-big {
        font-size: 2.5rem; /* Adjust the size as needed */
        margin-right: 20px; /* Adjust the margin as needed */
    }

    .progress-bar-container .main {
            width: 100%;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: 'Poppins-Medium', sans-serif;
            flex-direction: column;
        }

        .progress-bar-container ul {
            display: flex;
            margin-top: 20px; /* Reduced margin-top */
            justify-content: space-between; /* Added space-between to distribute items evenly */
            width: 100%; /* Ensure full width */
        }

        .progress-bar-container ul li {
            list-style: none;
            display: flex;
            flex-direction: column;
            align-items: center;
            flex: 1; /* Equal width for all items */
        }

        .progress-bar-container ul li .icon {
            font-size: 35px;
            color: var(--main-color);
        }

        .progress-bar-container ul li .text {
            font-size: 14px;
            font-weight: 600;
            color: var(--main-color);
            margin-top: 10px; /* Adjusted margin-top */
        }

        /* Progress Div Css */
        .progress-bar-container ul li .progress {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            background-color: var(--text-grey);
            display: grid;
            place-items: center;
            color: #fff;
            position: relative;
            cursor: pointer;
        }

        .progress-bar-container .progress::after {
            content: " ";
            position: absolute;
            height: 5px;
            background-color: var(--text-grey);
            left: 0;
            /*top: 50%;*/
            transform: translateX(-100%);
            z-index: -1;
            width: calc(4500% / (8 - 1) - 60px / (8 - 1)); /* Adjusted width */
        }

        .progress-bar-container.first .progress::after {
            width: calc(4500% / (8 - 1) - 60px / (8 - 1)); /* Adjusted width for the first progress bar */
        }

        .progress-bar-container.second .progress::after {
            width: calc(4500% / (6 - 1) - 60px / (6 - 1)); /* Adjusted width for the second progress bar */
        }

        .progress-bar-container .one::after {
            width: 0;
            height: 0;
        }

        .progress-bar-container ul li .progress .uil {
            display: none;
        }

        .progress-bar-container ul li .progress p {
            font-size: 13px;
        }

        /* Active Css */
        .progress-bar-container ul li .active {
            background-color: var(--main-color);
            display: grid;
            place-items: center;
        }

        .progress-bar-container li .active::after {
            background-color: var(--main-color);
        }

        .progress-bar-container ul li .active p {
            display: none;
        }

        .progress-bar-container ul li .active .uil {
            font-size: 20px;
            display: flex;
        }

        /* Responsive Css */
        @media (max-width: 980px) {
            .progress-bar-container ul {
                flex-direction: column;
            }

            .progress-bar-container ul li {
                flex-direction: row;
                margin-bottom: 10px; /* Adjusted margin-bottom */
            }

            .progress-bar-container ul li .progress {
                margin: 0 30px;
            }

            .progress-bar-container .progress::after {
                width: 5px;
                height: 55px;
                bottom: 30px;
                left: 50%;
                transform: translateX(-50%);
                z-index: -1;
            }

            .progress-bar-container .one::after {
                height: 0;
            }

            .progress-bar-container ul li .icon {
                margin: 15px 0;
            }
        }

        @media (max-width:600px) {
            .progress-bar-container .head .head_1 {
                font-size: 24px;
            }

            .progress-bar-container .head .head_2 {
                font-size: 16px;
            }
        }


.progress-bar-card {
    position: relative;
    margin-top: 0rem; /* Space it from the previous card */
    /*margin-left: 345px; /* Initial sidebar width */
    /*margin-right: 1.5rem; /* Right padding */
    z-index: 99; /* Ensure it stays above other elements */
    width: calc(154%); /* Width of the screen minus sidebar width and right padding */
    left: 0; /* Align it to the left */
    right: 1rem
}

.progress-bar-card .card-body {
    display: flex;
    justify-content: center; /* Horizontally center the content */
    align-items: center; /* Vertically center the content */
    height: 50%; /* Set height to ensure centering works */
}

.progress-bars-container {
    display: flex;
    flex-direction: column;
    gap: 20px; /* Gap between progress bars */
}

</style>
</head>
<body>

    <input type="checkbox" id="nav-toggle" checked>
	<div class="sidebar">
    	<div class="sidebar-brand">
        	<h2><span class="las la-seedling"></span> <span>SproutBot</span>
            </h2>
            </div>
            
            <div class="sidebar-menu">
            	<ul>
                	<li>
                    	<a href="" class="active"><span class="las la-home"></span>
                        <span>Dashboard</span></a>
                    </li>
                    <li>
                    	<a href=""><span class="las la-leaf"></span>
                        <span>My Plants</span></a>
                    </li>
                    <li>
                    	<a href=""><span class="las la-laptop-code"></span>
                        <span>My Robot</span></a>
                    </li>
                    <li>
                    	<a href=""><span class="las la-trophy"></span>
                        <span>About</span></a>
                    </li>
               </ul>
           </div>
       </div>
                    

    <div class="main-content">
        <header>
        	<h2>
            	<label for="nav-toggle">
                	<span class="las la-bars"></span>
                </label>
                
                Dashboard
            </h2>
            
            <div class="user-wrapper">
            	<div>
                	<h4>Mina Demian</h4>
                    <small>Admin</small>
        
        </header>
        
        <button id="armButton" class="arm-button" onclick="triggerArmFunction()">Test Arm</button>
        
        <main>
        
        	<div class="cards">
            	<div class="card-single">
                	<div>
                    	<h1 id="totalPlants">--</h1>
                        <span>Plants</span>
                    </div>
                    <div>
                    	<span class="las la-leaf"></span>
                    </div>
                </div>

                <div class="card-single">
                	<div>
                    	<h1 id="successfulTrips">--</h1>
                        <span>Successful Trips Today</span>
                    </div>
                    <div>
                    	<span class="las la-calendar-check"></span>
                    </div>
                </div>

                <div class="card-single">
                	<div>
                    	<h1 id="totalTrips">--</h1>
                        <span>Trips Today</span>
                    </div>
                    <div>
                    	<span class="las la-map"></span>
                    </div>
                </div>
                
                <div class="card-single">
                	<div>
                    	<h1 id="waterUsed">--</h1>
                        <span>Water Used Today</span>
                    </div>
                    <div>
                    	<span class="las la-tint"></span>
                    </div>
                </div>
            </div>

            <div class="recent-grid">
                <div class="projects">
                    <div class="card">
                        <div class="card-header">
                            <h2>Water Runs</h2>

                            <button>See all <span class="las la-arrow-right">
                            </span></button>
                        </div>

                        <div class="card-body">
                            <div class="table-responsive">
                                <table width="100%">
                                    <thead>
                                        <tr>
                                            <td>Time</td>
                                            <td>Plant</td>
                                            <td>Status</td>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <!--
                                        <tr>
                                            <td>7:00 pm</td>
                                            <td>Plant 1</td>
                                            <td>
                                                <span class="status blue"></span>
                                                Waiting
                                            </td>
                                        </tr>
                                        -->
                                        <tr>
                                            <td>9:48:23 AM</td>
                                            <td>Plant 3</td>
                                            <td>
                                                <span class="status green"></span>
                                                Successful
                                            </td>
                                        </tr>
    
                                        <tr>
                                            <td>9:33:18 AM</td>
                                            <td>Plant 2</td>
                                            <td>
                                                <span class="status red"></span>
                                                Failed
                                            </td>
                                        </tr>
    
                                        <tr>
                                            <td>8:07:46 AM</td>
                                            <td>Plant 1</td>
                                            <td>
                                                <span class="status green"></span>
                                                Successful
                                            </td>
                                        </tr>
    
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="Plants">
                    <div class="card">
                        <div class="card-header">
                            <h2>Water Levels</h2>
                            <button>See all <span class="las la-arrow-right">
                            </span></button>
                        </div>

                        <div class="card-body">
                            <div class="Plant">
                                <div class="info">
                                    <span class="icon-big lab la-canadian-maple-leaf"></span>
                                    <h4>Plant 1</h4>
                                    <small id="plant1WaterLevel">%d%% </small>
                                </div>
                                <div class="progress-bar">
                                    <div id="plant1WaterLevelBar" class="water-level" style="width: %d%%;"></div>
                                </div>
                            </div>
                    
                            <div class="Plant">
                                <div class="info"> 
                                    <span class="icon-big la la-pagelines"></span>
                                    <h4>Plant 2</h4>
                                    <small id="plant2WaterLevel">%d%% </small>
                                </div>
                                <div class="progress-bar">
                                    <div id="plant2WaterLevelBar" class="water-level" style="width: %d%%;"></div>
                                </div>
                            </div>
                    
                            <div class="Plant">
                                <div class="info"> 
                                    <span class="icon-big las la-spa"></span>
                                    <h4>Plant 3</h4>
                                    <small id="plant3WaterLevel">%d%% </small>
                                </div>
                                <div class="progress-bar">
                                    <div id="plant3WaterLevelBar" class="water-level" style="width: %d%%;"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

<!-- Container for Progress Bars -->
<div class="progress-bars-container">
                              <!-- New Component: Animated Step Progress Bar -->
<div class="card progress-bar-card">
    <div class="card-header">
        <h2>Robot Stages</h2>
    </div>

    <div class="card-body progress-bar-container first">
        <ul>
            <li class="step" data-step="0">
                <i class="icon uil uil-house-user"></i>
                <div class="progress one">
                    <p>1</p>
                    <i class="uil uil-check"></i>
                </div>
                <p class="text">Waiting</p>
            </li>
            <li class="step" data-step="1">
                <i class="icon uil uil-map-marker"></i>
                <div class="progress two">
                    <p>2</p>
                    <i class="uil uil-check"></i>
                </div>
                <p class="text">Finding Plant</p>
            </li>
            <li class="step" data-step="2">
                <i class="icon uil uil-streering"></i>
                <div class="progress three">
                    <p>3</p>
                    <i class="uil uil-check"></i>
                </div>
                <p class="text">Moving to Plant (IR)</p>
            </li>
            <li class="step" data-step="3">
                <i class="icon uil uil-car-sideview"></i>
                <div class="progress four">
                    <p>4</p>
                    <i class="uil uil-check"></i>
                </div>
                <p class="text">Moving Closer (US)</p>
            </li>
            <li class="step" data-step="4">
                <i class="icon uil uil-tear
                "></i>
                <div class="progress five">
                    <p>5</p>
                    <i class="uil uil-check"></i>
                </div>
                <p class="text">Watering</p>
            </li>
            <li class="step" data-step="5">
                <i class="icon uil uil-home"></i>
                <div class="progress six">
                    <p>6</p>
                    <i class="uil uil-check"></i>
                </div>
                <p class="text">Finding Base</p>
            </li>
            <li class="step" data-step="6">
                <i class="icon uil uil-corner-right-down"></i>
                <div class="progress seven">
                    <p>7</p>
                    <i class="uil uil-check"></i>
                </div>
                <p class="text">Moving to Base (IR)</p>
            </li>
            <li class="step" data-step="7">
                <i class="icon uil uil-car"></i>
                <div class="progress eight">
                    <p>8</p>
                    <i class="uil uil-check"></i>
                </div>
                <p class="text">Moving Closer (US)</p>
            </li>
        </ul>
    </div>
</div>

                              <!-- New Component: Animated Step Progress Bar -->
<div class="card progress-bar-card">
    <div class="card-header">
        <h2>Watering Arm Stages</h2>
    </div>

    <div class="card-body progress-bar-container second">
        <ul>
            <li class="step" data-step="0">
                <i class="icon uil uil-arrows-h"></i>
                <div class="progress one">
                    <p>1</p>
                    <i class="uil uil-check"></i>
                </div>
                <p class="text">Extending</p>
            </li>
            <li class="step" data-step="1">
                <i class="icon uil uil-search-alt"></i>
                <div class="progress two">
                    <p>2</p>
                    <i class="uil uil-check"></i>
                </div>
                <p class="text">Detecting Height</p>
            </li>
            <li class="step" data-step="2">
                <i class="icon uil uil-search-plus"></i>
                <div class="progress three">
                    <p>3</p>
                    <i class="uil uil-check"></i>
                </div>
                <p class="text">Moving Closer to Soil</p>
            </li>
            <li class="step" data-step="3">
                <i class="icon uil uil-map-marker-shield"></i>
                <div class="progress four">
                    <p>4</p>
                    <i class="uil uil-check"></i>
                </div>
                <p class="text">Looking for Soil</p>
            </li>
            <li class="step" data-step="4">
                <i class="icon uil uil-tear
                "></i>
                <div class="progress five">
                    <p>5</p>
                    <i class="uil uil-check"></i>
                </div>
                <p class="text">Watering</p>
            </li>
            <li class="step" data-step="5">
                <i class="icon uil uil-refresh"></i>
                <div class="progress six">
                    <p>6</p>
                    <i class="uil uil-check"></i>
                </div>
                <p class="text">Resetting Arm</p>
            </li>
        </ul>
    </div>
</div>
</div>

            </div>

            

         </main>
    </div>

  <script>

  // Counter variable to keep track of button clicks
  //let armButtonClicks = 0;

  function triggerArmFunction() {
      // Increment the counter
      //armButtonClicks++;

      // Update the counter inside the button
      //document.getElementById('armCounter').innerText = armButtonClicks;

      // Send GET request to the arm_function endpoint with value=1
      fetch('/arm_function?value=1')
      .then(response => {
        if (response.ok) {
          console.log('Arm function triggered successfully');
        } else {
          console.error('Failed to trigger arm function');
          }
      })
      .catch(error => {
        console.error('Error triggering arm function:', error);
      });
    }

  // Function to fetch water level data from server
  function fetchWaterLevels() {
    fetch('/get_water_levels')
    .then(response => response.json())
    .then(data => {
        //document.getElementById('plant1WaterLevel').innerText = data.plant1WaterLevel + '%';
        //document.getElementById('plant1WaterLevelBar').style.width = data.plant1WaterLevel + '%';

        document.getElementById('plant2WaterLevel').innerText = data.plant2WaterLevel + '%';
        document.getElementById('plant2WaterLevelBar').style.width = data.plant2WaterLevel + '%';

        document.getElementById('plant3WaterLevel').innerText = data.plant3WaterLevel + '%';
        document.getElementById('plant3WaterLevelBar').style.width = data.plant3WaterLevel + '%';

        document.getElementById('totalPlants').innerText = data.totalPlants;
        //document.getElementById('successfulTrips').innerText = data.successfulTrips;
        //document.getElementById('totalTrips').innerText = data.totalTrips;
        //document.getElementById('waterUsed').innerText = data.waterUsed + ' mL';

    });
}

let plant1WaterLevel = 30; // Initial value of plant1WaterLevel

function updateProgressBar(data) {
    const progressSteps = document.querySelectorAll('.progress-bars-container .progress-bar-card:nth-child(1) .step');
    
    progressSteps.forEach(step => {
        step.querySelector('.progress').classList.remove('active');
    });

    for (let i = 0; i < data.index; i++) {
        progressSteps[i].querySelector('.progress').classList.add('active');
    }

    // Check if the progress bar passes the watering stage (step 6)
    if (data.index === 6) {
        // Update the Plant1WaterLevel to 100%
        plant1WaterLevel = 100; // Set plant1WaterLevel to 100%
    } /*else {
        // Decrement the Plant1WaterLevel by 1%
        plant1WaterLevel = Math.max(plant1WaterLevel - 1, 0); // Ensure it doesn't go below 0
    }*/

    // Update the plant1WaterLevel element
    document.getElementById('plant1WaterLevel').innerText = plant1WaterLevel + '%';
    // Update the width of the water level progress bar
    document.getElementById('plant1WaterLevelBar').style.width = plant1WaterLevel + '%';

}

function fetchWateringArmState() {
    fetch('/get_state')
    .then(response => response.json())
    .then(data => {
        const stateValue = data.state;
        let updatedData = { ...data }; // Clone the data object

        // Default the index to 5
        updatedData.index = 5;

        // Update the first progress bar to the "Finding Base Stage" (index 6)
        if (stateValue === 5) {
            updatedData.index = 6;
            console.log('Updating first progress bar to Finding Base Stage');
        }

        console.log('Received stateValue:', stateValue); // Log received stateValue
        updateWateringArmProgressBar(data); // Call the function to update the watering arm progress bar

        // Pass the updated data with the correct index to the progress bar update function
        updateProgressBar(updatedData);  
        updateRecentWaterRuns(updatedData); // Update the recent water runs table with the updated data
    })
    .catch(error => {
        console.error('Error fetching Watering Arm state:', error);
    });
}

function updateWateringArmProgressBar(data) {
    const mainColor = data.state === 4 ? 'rgba(62,164,240)' : 'rgba(53, 136, 86)'; // Change main color to blue if the state is 4

    // Set the value of --main-color CSS variable on the :root element
    document.documentElement.style.setProperty('--main-color', mainColor);
    
    const progressSteps = document.querySelectorAll('.progress-bars-container .progress-bar-card:nth-child(2) .step');
    
    progressSteps.forEach(step => {
        step.querySelector('.progress').classList.remove('active');
    });

  
    for (let i = 0; i <= data.state; i++) {
        if (progressSteps[i]) {
            progressSteps[i].querySelector('.progress').classList.add('active');
        }
    }
}

/*
// Function to update the second progress bar based on the state value
function updateSecondProgressBar(stateValue) {
  const progressBarSteps = document.querySelectorAll('.second-progress-bar .step');

  // Reset all steps to inactive
  progressBarSteps.forEach(step => {
    step.classList.remove('active');
  });

  // Activate steps based on the state value
  for (let i = 0; i <= stateValue; i++) {
    if (progressBarSteps[i]) {
      progressBarSteps[i].classList.add('active');
    }
  }

  // Check if the state is equal to 4
    if (data.state === 4) {
        // Change the background color of the progress bar container to blue
        progressBarContainer.style.backgroundColor = 'blue';
    } else {
        // Reset the background color to default if the state is not 4
        progressBarContainer.style.backgroundColor = '';
    }
}

// Fetch the state value from the Arduino server
fetch('/get_state')
  .then(response => response.json())
  .then(data => {
    const stateValue = data.state;
    updateSecondProgressBar(stateValue);
  })
  .catch(error => {
    console.error('Error fetching state:', error);
  });
*/

/*
// New function to update the second progress bar
function updateSecondProgressBar(state) {
    const progressSteps = document.querySelectorAll('.second-step');

    progressSteps.forEach(step => {
        step.querySelector('.progress').classList.remove('active');
    });

    for (let i = 0; i < state; i++) {
        progressSteps[i].querySelector('.progress').classList.add('active');
    }
}
*/

/*
// Function to fetch the 'state' value and update the second progress bar
function updateProgressFromState() {
    fetch('/index.html')
    .then(response => {
        const stateHeader = response.headers.get('state');
        return stateHeader;
    })
    .then(state => {
        updateSecondProgressBar(state);
    })
    .catch(error => {
        console.error('Error fetching state:', error);
    });
}
*/

function updateWaterRunCounts() {
    const tableBody = document.querySelector('.table-responsive tbody');
    const rows = tableBody.querySelectorAll('tr');

    let totalTrips = 0;
    let successfulTrips = 0;
    let waterUsedToday = 0;

    rows.forEach(row => {
        const statusCell = row.querySelector('.status');

        totalTrips++;

        if (statusCell.classList.contains('green')) {
            successfulTrips++;
            waterUsedToday += 45; // Add 45 mL for each successful trip
        }
    });

    document.getElementById('totalTrips').innerText = totalTrips;
    document.getElementById('successfulTrips').innerText = successfulTrips;
    document.getElementById('waterUsed').innerText = `${waterUsedToday} mL`;
}

//let inProgressRow = null; // Variable to hold the in-progress row

let inProgressAdded = false;
let completedAdded = false;

function updateRecentWaterRuns(data) {
    const tableBody = document.querySelector('.table-responsive tbody');

    // Check if the robot is at the 5th step and "In Progress" row is not added
    if (data.index === 5 && !inProgressAdded) {
        // Add a new "In Progress" row
        const newRow = `
            <tr>
                <td>${new Date().toLocaleTimeString()}</td>
                <td>Plant 1</td>
                <td>
                    <span class="status orange"></span>
                    In Progress
                </td>
            </tr>
        `;

        tableBody.insertAdjacentHTML('afterbegin', newRow);

        // Set the "In Progress" flag
        inProgressAdded = true;

        // Reset the "Completed" flag
        completedAdded = false;

        // Update counts
        updateWaterRunCounts();
    }

    // Check if the robot is at the 6th step of the progress bar
    if (data.index === 6 && !completedAdded) {
        // Remove the "In Progress" row if it exists
        const inProgressRow = tableBody.querySelector('.status.orange');
        if (inProgressRow) {
            inProgressRow.parentElement.parentElement.remove();
        }

        // Add a new "Completed" row
        const newRow = `
            <tr>
                <td>${new Date().toLocaleTimeString()}</td>
                <td>Plant 1</td>
                <td>
                    <span class="status green"></span>
                    Successful
                </td>
            </tr>
        `;

        tableBody.insertAdjacentHTML('afterbegin', newRow);

        // Set the "Completed" flag
        completedAdded = true;

        // Set the "In Progress" flag
        inProgressAdded = false;

        // Update counts
        updateWaterRunCounts();
    }
}

function fetchState() {
  //updateProgressFromState();  // Fetch and update the second progress bar
    // Create a mock data object with index set to 5
    const mockData = {
        index: 5
    };

    // Call the update functions with the mock data
    updateProgressBar(mockData);
    updateRecentWaterRuns(mockData); // Update the recent water runs table
}

/*
function fetchState() {
    fetch('/getState')
    .then(response => response.json())
    .then(data => {
        updateProgressBar(data);
        updateRecentWaterRuns(data); // Update the recent water runs table
    })
    .catch(error => {
        console.error('Error fetching state:', error);
    });
}
*/
      // Function to handle reload event and refresh the page
      function handleReload(event) {
        if (event.data === 'reload') {
          window.location.reload();
        }
      }

      // Event listener for reload event
      const events = new EventSource('/events');
      events.addEventListener('reload', fetchWaterLevels); //use handleReload instead of fetchWaterLevels if you want to refresh whole webpage

      // Fetch water levels when the page loads
      fetchWaterLevels();

      // Refresh water levels every minute
      setInterval(fetchWaterLevels, 60000);

      // Fetch state initially
      fetchState();

      // Event listener for reload event
      events.addEventListener('reload', fetchState);

      // Set interval to periodically fetch state
      setInterval(fetchState, 30000); // Fetch every 5 seconds

      // Fetch the state value for Watering Arm Stages initially
      fetchWateringArmState();

      // Set interval to periodically fetch state
      setInterval(fetchWateringArmState, 1000); // Fetch every 30 seconds

      // Update counts
      updateWaterRunCounts();

      // Fetch water levels when the Whole Webpage loads if we use the Full Webpage Refresh
      //window.onload = fetchWaterLevels;
    </script>
</body>
</html>
)rawliteral";

#endif // INDEX_H